<html>
   <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="views/css/bootstrap.min.css">
    <title>Aplicacion Hacienda</title>
    </head>
      
    <body>
		<h1 class="text-center">Aplicacion Hacienda</h1>
				<div class="form-group">
					<input type="button" value="Registro Empleado Hacienda" onclick="window.location.href='controllers/Registro_controllers.php'" class="btn btn-warning disabled">
					<input type="button" value="Login Hacienda" onclick="window.location.href='controllers/Login_controllers.php'" class="btn btn-warning disabled">
				</div>
	</body>
</html>
