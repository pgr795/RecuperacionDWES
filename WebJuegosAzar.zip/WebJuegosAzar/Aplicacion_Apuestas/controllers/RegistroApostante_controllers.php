<?php	
include_once '../views/RegistroApostante_views.php';
?>