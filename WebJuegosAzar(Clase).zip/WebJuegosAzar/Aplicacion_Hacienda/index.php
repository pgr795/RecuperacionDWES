<?php
setcookie('PHPSESSID', '', time() - 86400, '/');
include_once 'views/Hacienda_views.php';
?>