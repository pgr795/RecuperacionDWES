<html>
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../views/css/bootstrap.min.css">
    <title>Login Hacienda:</title>
 </head>
      
<body>
    <h1>Login Hacienda:</h1>

    <div class="container ">
        <!--Aplicacion-->
	
		<form id="" name="" action="" method="post" class="card-body">
		
		<div class="form-group">
			Usuario <input type="text" name="dni" placeholder="dni" class="form-control" maxlength="9">
        </div>
		<div class="form-group">
			Contraseña <input type="password" name="password" placeholder="contraseña" class="form-control">
        </div>				
        
		<input type="submit" name="submit" value="Login" class="btn btn-warning disabled">
        </form>	
	</div>
</body>
</html>