<html>
   <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="views/css/bootstrap.min.css">
    <title>Aplicación Apuestas</title>
    </head>
      
    <body>
		<h1 class="text-center">Aplicación Apuestas</h1>
				<div class="form-group">
					<input type="button" value="Registro Apostante" onclick="window.location.href='controllers/RegistroApostante_controllers.php'" class="btn btn-warning disabled">
					<input type="button" value="Login Apostante" onclick="window.location.href='controllers/LoginApostante_controllers.php'" class="btn btn-warning disabled">
				</div>
	</body>
</html>
